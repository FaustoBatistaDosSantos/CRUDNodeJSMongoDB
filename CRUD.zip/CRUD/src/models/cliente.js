//importa o mongoose
const mongoose = require('mongoose');

const mongoosePaginate = require('mongoose-paginate');


//vamos criar o schema (model) do banco de dados
const ClienteSchema = new mongoose.Schema({
    //vamos passar qual campo quero salvar no banco de dados
    Nome: {
        type: String,
        required: true,
        uppercase: true,
        minlength: 3,
        maxlength: 100
    },
    Idade: {
        type: Number,
        required: true
    },
    Ativo: {
        type: Boolean,
        default: true,
        required: true,
    },
    DataCadastro:{
        type: Date,
        default: Date.now
    }    
});

//adiciona o plugin para permitir paginacao
ClienteSchema.plugin(mongoosePaginate);

//registro o model na nossa aplicacao
mongoose.model('Cliente', ClienteSchema);