const mongoose = require('mongoose');

//carrego o modelo de dados
const Cliente = mongoose.model('Cliente');


module.exports = {
    
    //cria a funcao de tela de insert
    //nela executa a funcao de insert no banco de dados
    //os dados sao passados no corpo da requisicao via post
    async Inserir (req, res) {
        const clientes = await Cliente.create(req.body);

        return res.json(clientes);
    },
    
    async Listar (req, res) {
        //body - corpo da requisicao
        //params - id definido na rota e outras info
        //query - parametros get (pego o parametro page que esta no get, posso definir valor default)
        const { page } = req.query;

        //depois posso usar o paginate 
        //limite de 10 pagina e inicia na 1
        const clientes = await Cliente.paginate({}, { page, limit: 5 });

        return res.json(clientes);
    },

    //cria a funcao de tela de detalhes
    async Obter (req, res) {
        //a requisicao traz os parametros informados, sendo buscado o id (GET)
        const clientes = await Cliente.findById(req.params.id);

        return res.json(clientes);
    },

    async Atualizar (req, res) {
        const clientes = await Cliente.findByIdAndUpdate(req.params.id, req.body, { new: true });

        return res.json(clientes);
    },


    async Deleta (req, res) {
        await Cliente.findByIdAndRemove(req.params.id);

        return res.send();
    },

};


