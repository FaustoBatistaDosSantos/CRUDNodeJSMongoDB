const express = require('express');
const routes = express.Router();

const usuarioController = require("../controller/usuarios.js");
const clienteController = require("../controller/cliente.js");

//toda vez q o usuario acessar a rota (rota raiz), tem a funcao que recebe o req e res
//req simboliza a requisicao que esta sendo feita ao servidor 
//req contém os dados dessa requisicao, parametros, corpo, cabecalho, autenticacao, usuario, ip, etc.)
//res - resposta que vai ser dada a requisicao (resposta do servidor)

//********************************************************CRUD DE USUARIOS */

//quando criar algo, usa post
//insert
routes.post('/usuarios', usuarioController.Inserir);

//quando buscar, pode ser get
//select
routes.get('/usuarios', usuarioController.Listar);

//details
routes.get('/usuarios/:id', usuarioController.Obter);

//update
routes.put('/usuarios/:id', usuarioController.Atualizar);

//update
routes.delete('/usuarios/:id', usuarioController.Deleta);

//********************************************************CRUD DE CLIENTE */


routes.post('/cliente', clienteController.Inserir);

//quando buscar, pode ser get
//select
routes.get('/cliente', clienteController.Listar);

//details
routes.get('/cliente/:id', clienteController.Obter);

//update
routes.put('/cliente/:id', clienteController.Atualizar);

//update
routes.delete('/cliente/:id', clienteController.Deleta);


module.exports = routes;